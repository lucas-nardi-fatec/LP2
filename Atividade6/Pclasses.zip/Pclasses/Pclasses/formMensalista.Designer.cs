﻿namespace Pclasses
{
    partial class formMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSMensal = new System.Windows.Forms.TextBox();
            this.txtDEntrada = new System.Windows.Forms.TextBox();
            this.btnIMens = new System.Windows.Forms.Button();
            this.btnIMensPP = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label1.Location = new System.Drawing.Point(93, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Matrícula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label2.Location = new System.Drawing.Point(93, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label3.Location = new System.Drawing.Point(93, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 26);
            this.label3.TabIndex = 2;
            this.label3.Text = "Salário Mensal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label4.Location = new System.Drawing.Point(93, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(294, 26);
            this.label4.TabIndex = 3;
            this.label4.Text = "Data de Entrada na Empresa";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtMatricula.Location = new System.Drawing.Point(418, 74);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(130, 29);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtNome.Location = new System.Drawing.Point(418, 109);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(388, 29);
            this.txtNome.TabIndex = 5;
            // 
            // txtSMensal
            // 
            this.txtSMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtSMensal.Location = new System.Drawing.Point(418, 144);
            this.txtSMensal.Name = "txtSMensal";
            this.txtSMensal.Size = new System.Drawing.Size(130, 29);
            this.txtSMensal.TabIndex = 6;
            // 
            // txtDEntrada
            // 
            this.txtDEntrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtDEntrada.Location = new System.Drawing.Point(418, 181);
            this.txtDEntrada.Name = "txtDEntrada";
            this.txtDEntrada.Size = new System.Drawing.Size(130, 29);
            this.txtDEntrada.TabIndex = 7;
            // 
            // btnIMens
            // 
            this.btnIMens.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnIMens.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.btnIMens.Location = new System.Drawing.Point(98, 287);
            this.btnIMens.Name = "btnIMens";
            this.btnIMens.Size = new System.Drawing.Size(288, 116);
            this.btnIMens.TabIndex = 8;
            this.btnIMens.Text = "Instanciar Mensalista";
            this.btnIMens.UseVisualStyleBackColor = false;
            this.btnIMens.Click += new System.EventHandler(this.btnIMens_Click);
            // 
            // btnIMensPP
            // 
            this.btnIMensPP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnIMensPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnIMensPP.Location = new System.Drawing.Point(458, 287);
            this.btnIMensPP.Name = "btnIMensPP";
            this.btnIMensPP.Size = new System.Drawing.Size(288, 116);
            this.btnIMensPP.TabIndex = 9;
            this.btnIMensPP.Text = "Instanciar Mensalista(passando parametros)";
            this.btnIMensPP.UseVisualStyleBackColor = false;
            this.btnIMensPP.Click += new System.EventHandler(this.btnIMensPP_Click);
            // 
            // formMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(849, 488);
            this.Controls.Add(this.btnIMensPP);
            this.Controls.Add(this.btnIMens);
            this.Controls.Add(this.txtDEntrada);
            this.Controls.Add(this.txtSMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "formMensalista";
            this.Text = "formMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSMensal;
        private System.Windows.Forms.TextBox txtDEntrada;
        private System.Windows.Forms.Button btnIMens;
        private System.Windows.Forms.Button btnIMensPP;
    }
}