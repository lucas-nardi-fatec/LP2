﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notasTelespecs = new double[3, 2];

            double[] somaF = new double[2];

            string aux = "";
            string auxInput = "";

            for(int i = 0; i < 3; i++)
            {
                auxInput = $"Pessoa {i+1}";

                for(int j = 0; j < 2; j++)
                {
                    aux = Interaction.InputBox($"Insira a nota da {i + 1}ª pessoa para o {j + 1}° filme", "Entrada de Notas");

                    if (!double.TryParse(aux, out notasTelespecs[i, j]) || (notasTelespecs[i, j] < 0 || notasTelespecs[i, j] > 10))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else {
                        auxInput += $" Nota Filme {j+1}: " + notasTelespecs[i,j].ToString("N2");
                        somaF[j] += notasTelespecs[i, j];
                    }
                }

                auxInput += " Média das notas: " + ((notasTelespecs[i, 0] + notasTelespecs[i, 1]) / 2).ToString("N2");
                lstBoxFilmes.Items.Add(auxInput);
            }

            somaF[0] = somaF[0] / 3;
            somaF[1] = somaF[1] / 3;

            lstBoxFilmes.Items.Add("--------------------------");

            lstBoxFilmes.Items.Add("Média Filme 1: " + somaF[0].ToString("N2"));
            lstBoxFilmes.Items.Add("Média Filme 2: " + somaF[1].ToString("N2"));

            lstBoxFilmes.Items.Add("--------------------------");
            lstBoxFilmes.Items.Add("                          ");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            lstBoxFilmes.Items.Clear();
        }
    }
}
