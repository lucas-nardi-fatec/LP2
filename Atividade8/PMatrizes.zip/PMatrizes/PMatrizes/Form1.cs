﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for(int i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}° número inteiro: ", "Entrada de Dados");

                if(!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("número inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            aux = "";
            foreach(int x in vetor)
            {
                aux += x + "\n";
            }

            MessageBox.Show(aux);

        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };

            lista.Remove("Otávio");
            string aux = "";

            foreach (string x in lista)
            {
                aux += x + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string aux = "";
            string saida = "";

            for(int i = 0; i < 20; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Insira a {j + 1}ª nota do {i + 1}° aluno: ", "Entrada de Notas");
                    
                    if(!double.TryParse(aux, out notas[i,j]) || 0.0 > notas[i, j] || notas[i, j] > 10.0)
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    } 
                }

                saida += $"Aluno {i + 1}: média: {(notas[i,0] + notas[i,1] + notas[i,2]) / 3}\n";

            }

            MessageBox.Show(saida);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();

            }
            else
            {
                frmExercicio4 fEx4 = new frmExercicio4();
                fEx4.Show();

            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"].BringToFront();

            }
            else
            {
                frmExercicio5 fEx5 = new frmExercicio5();
                fEx5.Show();

            }
        }
    }
}
