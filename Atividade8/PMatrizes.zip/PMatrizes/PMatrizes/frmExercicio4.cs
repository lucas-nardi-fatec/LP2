﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBoxNomes.Items.Clear();
            string[] vetor = new string[10];
            int auxCount = 0;

            for(int i = 0; i < 10; i++)
            {
                vetor[i] = Interaction.InputBox("Insira o nome da pessoa: ", "Entrada de dados");
                auxCount = 0;

                for(int j = 0; j < vetor[i].Length; j++)
                {
                    if (vetor[i][j] != ' ')
                    {
                        auxCount++;
                    }
                }

                listBoxNomes.Items.Add("O nome: " + vetor[i] + $" tem {auxCount} caracteres");

            }
        }
    }
}
