﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int ALUNOS = 8;
            char[,] respostasAlunos = new char[ALUNOS, 10];
            char[] gabarito = new char[10] {'B','C','C','A','B','E','D','C','A','D'};
            char[] notasPossiveis = new char[5] { 'A', 'B', 'C', 'D', 'E' };

            string aux = "";

            for(int i = 0; i < ALUNOS; i++)
            {
                for(int j = 0; j < 10; j++)
                {
                    aux = Interaction.InputBox($"Insira a resposta do aluno na questão {j+1}", "Entrada de Respostas");

                    if(!char.TryParse(aux, out respostasAlunos[i, j]) || !notasPossiveis.Contains(respostasAlunos[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    } else
                    {
                        if(respostasAlunos[i,j] == gabarito[j])
                        {
                            lstBoxAlNotas.Items.Add($"O aluno {i + 1} acertou questão {j + 1} era {gabarito[j]} escolheu {respostasAlunos[i, j]}");
                        } else
                        {
                            lstBoxAlNotas.Items.Add($"O aluno {i + 1} errou questão {j + 1} era {gabarito[j]} escolheu {respostasAlunos[i, j]}");
                        }
                    }
                }
            }

        }
    }
}
