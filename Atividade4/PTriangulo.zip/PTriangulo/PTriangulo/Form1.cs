﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
 

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        string tipoTriangulo;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtBoxLadoA.Text = "";
            txtBoxLadoB.Text = "";
            txtBoxLadoC.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            
            if(!(Double.TryParse(txtBoxLadoA.Text, out ladoA) && ladoA > 0))
            {
                MessageBox.Show("Coloque um valor numérico positivo em Lado A e tente novamente.");
                txtBoxLadoA.Clear();
            }

            else if (!(Double.TryParse(txtBoxLadoB.Text, out ladoB) && ladoB > 0))
            {
                MessageBox.Show("Coloque um valor numérico positivo em Lado B e tente novamente.");
                txtBoxLadoB.Clear();
            }

            else if (!(Double.TryParse(txtBoxLadoC.Text, out ladoC) && ladoC > 0))
            {
                MessageBox.Show("Coloque um valor numérico positivo em Lado C e tente novamente.");
                txtBoxLadoC.Clear();
            }
            else
            {
                if(Math.Abs(ladoB - ladoC) < ladoA && ladoA < ladoB + ladoC &&
                   Math.Abs(ladoA - ladoC) < ladoB && ladoB < ladoA + ladoC &&
                   Math.Abs(ladoA - ladoB) < ladoC && ladoC < ladoA + ladoB)
                {

                    if(ladoA != ladoB && ladoB != ladoC && ladoA != ladoC)
                    {
                        tipoTriangulo = "escaleno";
                    }

                    else if(ladoA == ladoB && ladoB == ladoC && ladoA == ladoC)
                    {
                        tipoTriangulo = "equilátero";
                    }

                    else
                    {
                        tipoTriangulo = "isósceles";
                    }

                    MessageBox.Show($"Os lados inseridos constituem um triângulo {tipoTriangulo}.");
                } else
                {
                    MessageBox.Show("Os lados inseridos não constituem um triângulo");
                }
            }

        }

        public Form1()
        {
            InitializeComponent();
        }



    }
}
