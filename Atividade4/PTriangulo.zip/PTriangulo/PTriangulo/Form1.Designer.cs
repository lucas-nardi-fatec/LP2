﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblLadoA = new System.Windows.Forms.Label();
            this.lblLadoB = new System.Windows.Forms.Label();
            this.lblLadoC = new System.Windows.Forms.Label();
            this.txtBoxLadoA = new System.Windows.Forms.TextBox();
            this.txtBoxLadoB = new System.Windows.Forms.TextBox();
            this.txtBoxLadoC = new System.Windows.Forms.TextBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.lblTitulo.Location = new System.Drawing.Point(12, 27);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(475, 37);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Insira o tamanho dos três lados:";
            // 
            // lblLadoA
            // 
            this.lblLadoA.AutoSize = true;
            this.lblLadoA.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblLadoA.Location = new System.Drawing.Point(19, 103);
            this.lblLadoA.Name = "lblLadoA";
            this.lblLadoA.Size = new System.Drawing.Size(87, 26);
            this.lblLadoA.TabIndex = 1;
            this.lblLadoA.Text = "Lado A:";
            // 
            // lblLadoB
            // 
            this.lblLadoB.AutoSize = true;
            this.lblLadoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblLadoB.Location = new System.Drawing.Point(20, 170);
            this.lblLadoB.Name = "lblLadoB";
            this.lblLadoB.Size = new System.Drawing.Size(87, 26);
            this.lblLadoB.TabIndex = 2;
            this.lblLadoB.Text = "Lado B:";
            // 
            // lblLadoC
            // 
            this.lblLadoC.AutoSize = true;
            this.lblLadoC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblLadoC.Location = new System.Drawing.Point(19, 244);
            this.lblLadoC.Name = "lblLadoC";
            this.lblLadoC.Size = new System.Drawing.Size(88, 26);
            this.lblLadoC.TabIndex = 3;
            this.lblLadoC.Text = "Lado C:";
            // 
            // txtBoxLadoA
            // 
            this.txtBoxLadoA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtBoxLadoA.Location = new System.Drawing.Point(112, 103);
            this.txtBoxLadoA.Name = "txtBoxLadoA";
            this.txtBoxLadoA.Size = new System.Drawing.Size(274, 29);
            this.txtBoxLadoA.TabIndex = 4;
            // 
            // txtBoxLadoB
            // 
            this.txtBoxLadoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtBoxLadoB.Location = new System.Drawing.Point(113, 170);
            this.txtBoxLadoB.Name = "txtBoxLadoB";
            this.txtBoxLadoB.Size = new System.Drawing.Size(274, 29);
            this.txtBoxLadoB.TabIndex = 5;
            // 
            // txtBoxLadoC
            // 
            this.txtBoxLadoC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.txtBoxLadoC.Location = new System.Drawing.Point(113, 244);
            this.txtBoxLadoC.Name = "txtBoxLadoC";
            this.txtBoxLadoC.Size = new System.Drawing.Size(274, 29);
            this.txtBoxLadoC.TabIndex = 6;
            // 
            // btnVerificar
            // 
            this.btnVerificar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnVerificar.Location = new System.Drawing.Point(53, 329);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(185, 148);
            this.btnVerificar.TabIndex = 7;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = false;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnLimpar.Location = new System.Drawing.Point(288, 329);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(185, 148);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnSair.Location = new System.Drawing.Point(527, 329);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(185, 148);
            this.btnSair.TabIndex = 9;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(752, 521);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.txtBoxLadoC);
            this.Controls.Add(this.txtBoxLadoB);
            this.Controls.Add(this.txtBoxLadoA);
            this.Controls.Add(this.lblLadoC);
            this.Controls.Add(this.lblLadoB);
            this.Controls.Add(this.lblLadoA);
            this.Controls.Add(this.lblTitulo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblLadoA;
        private System.Windows.Forms.Label lblLadoB;
        private System.Windows.Forms.Label lblLadoC;
        private System.Windows.Forms.TextBox txtBoxLadoA;
        private System.Windows.Forms.TextBox txtBoxLadoB;
        private System.Windows.Forms.TextBox txtBoxLadoC;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

